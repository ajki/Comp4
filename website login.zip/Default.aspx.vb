﻿Imports System.Data
Partial Class _Default
    Inherits System.Web.UI.Page

    Protected Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim dbProvider As String = "PROVIDER=Microsoft.Jet.OLEDB.4.0;"
        Dim dbSource As String = "Data Source= |DataDirectory|\login.mdb"
        Dim con As New OleDb.OleDbConnection(dbProvider & dbSource)

        Dim sql = "SELECT * " & "FROM logininfo " & "WHERE Username = '" & Username.Text & "'" & _
        "AND Password ='" & Password.Text & "'"

        con.Open()

        Dim dAdapter = New OleDb.OleDbDataAdapter(sql, con)
        Dim dSet = New DataSet
        dAdapter.Fill(dSet, "logininfo")
        Dim logininfo As New DataTable

        If dSet.Tables("logininfo").Rows.Count > 0 Then
            Label1.Text = "Welcome to my humble site " & Username.Text
            Server.Transfer("Homepage.aspx")

        Else
            Label1.Text = "Please sign up below."
        End If

        con.Close()
    End Sub
End Class
