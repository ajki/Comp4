﻿
Partial Class AskQuest
    Inherits System.Web.UI.Page

End Class
